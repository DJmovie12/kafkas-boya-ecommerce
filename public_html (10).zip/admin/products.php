<?php
require_once '../includes/db_connect.php';
require_once '../includes/session.php';

// Admin kontrolü
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Ürün silme işlemi (Pasif hale getirme)
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = $_GET['id'];
    
    try {
        // Ürünün sipariş geçmişini kontrol et
        $stmt = $conn->prepare("SELECT COUNT(*) as order_count FROM order_items WHERE product_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $order_data = $result->fetch_assoc();
        $stmt->close();
        
        if ($order_data['order_count'] > 0) {
            // Sipariş varsa ürünü pasif hale getir
            $stmt = $conn->prepare("UPDATE products SET stock = 0 WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            
            $_SESSION['success'] = 'Ürün sipariş geçmişi olduğu için stok 0 yapıldı. Artık satışta görünmeyecek.';
        } else {
            // Sipariş yoksa tamamen sil
            $stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $product = $result->fetch_assoc();
            $stmt->close();
            
            $conn->begin_transaction();
            
            // Sepetten sil
            $stmt = $conn->prepare("DELETE FROM cart WHERE product_id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            
            // Yorumlardan sil
            $stmt = $conn->prepare("DELETE FROM reviews WHERE product_id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            
            // Ürünü sil
            $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            
            $conn->commit();
            
            // Resmi sil
            if ($product['image'] && file_exists('../' . $product['image'])) {
                unlink('../' . $product['image']);
            }
            
            $_SESSION['success'] = 'Ürün başarıyla silindi!';
        }
        
        header('Location: products.php');
        exit();
        
    } catch (Exception $e) {
        if (isset($conn) && $conn) {
            $conn->rollback();
        }
        $_SESSION['error'] = 'İşlem sırasında hata oluştu: ' . $e->getMessage();
        header('Location: products.php');
        exit();
    }
}

// Ürünü aktif/pasif yapma işlemi
if (isset($_GET['action']) && $_GET['action'] === 'toggle_status' && isset($_GET['id'])) {
    $id = $_GET['id'];
    
    try {
        // Mevcut durumu al
        $stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_assoc();
        $stmt->close();
        
        // Stok durumunu değiştir (0 ise 10 yap, değilse 0 yap)
        $new_stock = $product['stock'] == 0 ? 10 : 0;
        
        $stmt = $conn->prepare("UPDATE products SET stock = ? WHERE id = ?");
        $stmt->bind_param("ii", $new_stock, $id);
        $stmt->execute();
        $stmt->close();
        
        $status = $new_stock == 0 ? 'pasif' : 'aktif';
        $_SESSION['success'] = "Ürün başarıyla {$status} hale getirildi!";
        header('Location: products.php');
        exit();
        
    } catch (Exception $e) {
        $_SESSION['error'] = 'Durum değiştirilirken hata oluştu: ' . $e->getMessage();
        header('Location: products.php');
        exit();
    }
}

// Stok kontrolü - stok 0 olan ürünleri otomatik pasif yap
$stock_check_stmt = $conn->prepare("SELECT id FROM products WHERE stock = 0");
$stock_check_stmt->execute();
$zero_stock_products = $stock_check_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stock_check_stmt->close();

// Helper function - array to string for database
function formatFeaturesForDB($features_array) {
    return implode('\\n', array_filter($features_array));
}

function formatSpecificationsForDB($specs_array) {
    $result = [];
    foreach ($specs_array as $spec) {
        if (!empty(trim($spec['key'])) && !empty(trim($spec['value']))) {
            $result[] = trim($spec['key']) . ': ' . trim($spec['value']);
        }
    }
    return implode('\\n', $result);
}

// Ürün ekleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'add') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $detailed_description = $_POST['detailed_description'];
    
    // Features array'i oluştur
    $features_array = [];
    if (isset($_POST['features']) && is_array($_POST['features'])) {
        $features_array = array_filter($_POST['features']);
    }
    $features = formatFeaturesForDB($features_array);
    
    $usage_instructions = $_POST['usage_instructions'];
    
    // Specifications array'i oluştur
    $specs_array = [];
    if (isset($_POST['spec_keys']) && isset($_POST['spec_values'])) {
        $keys = $_POST['spec_keys'];
        $values = $_POST['spec_values'];
        for ($i = 0; $i < count($keys); $i++) {
            if (!empty(trim($keys[$i])) && !empty(trim($values[$i]))) {
                $specs_array[] = [
                    'key' => $keys[$i],
                    'value' => $values[$i]
                ];
            }
        }
    }
    $specifications = formatSpecificationsForDB($specs_array);
    
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $brand_id = $_POST['brand_id'];
    $category_id = $_POST['category_id'];
    
    // Fotoğraf yükleme işlemi
    $image_path = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../assets/img/products/';
        
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        
        if (in_array($file_extension, $allowed_extensions)) {
            $new_filename = 'product_' . time() . '_' . uniqid() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                $image_path = 'assets/img/products/' . $new_filename;
            } else {
                $_SESSION['error'] = 'Dosya yüklenirken hata oluştu!';
            }
        } else {
            $_SESSION['error'] = 'Geçersiz dosya türü! Sadece JPG, PNG, WEBP veya GIF yükleyebilirsiniz.';
        }
    }
    
    if (!isset($_SESSION['error'])) {
        try {
            $stmt = $conn->prepare("
                INSERT INTO products (name, description, detailed_description, features, usage_instructions, specifications, price, stock, brand_id, category_id, image) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("ssssssdiiss", $name, $description, $detailed_description, $features, $usage_instructions, $specifications, $price, $stock, $brand_id, $category_id, $image_path);
            $stmt->execute();
            $stmt->close();
            
            $_SESSION['success'] = 'Ürün başarıyla eklendi!';
            header('Location: products.php');
            exit();
        } catch (Exception $e) {
            $_SESSION['error'] = 'Ürün eklenirken hata oluştu: ' . $e->getMessage();
        }
    }
}

// Ürün düzenleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'edit') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $detailed_description = $_POST['detailed_description'];
    
    // Features array'i oluştur
    $features_array = [];
    if (isset($_POST['features']) && is_array($_POST['features'])) {
        $features_array = array_filter($_POST['features']);
    }
    $features = formatFeaturesForDB($features_array);
    
    $usage_instructions = $_POST['usage_instructions'];
    
    // Specifications array'i oluştur
    $specs_array = [];
    if (isset($_POST['spec_keys']) && isset($_POST['spec_values'])) {
        $keys = $_POST['spec_keys'];
        $values = $_POST['spec_values'];
        for ($i = 0; $i < count($keys); $i++) {
            if (!empty(trim($keys[$i])) && !empty(trim($values[$i]))) {
                $specs_array[] = [
                    'key' => $keys[$i],
                    'value' => $values[$i]
                ];
            }
        }
    }
    $specifications = formatSpecificationsForDB($specs_array);
    
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $brand_id = $_POST['brand_id'];
    $category_id = $_POST['category_id'];
    
    // Mevcut resmi al
    $stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $current_product = $result->fetch_assoc();
    $stmt->close();
    
    $image_path = $current_product['image'];
    
    // Yeni fotoğraf yüklendiyse
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../assets/img/products/';
        
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        
        if (in_array($file_extension, $allowed_extensions)) {
            $new_filename = 'product_' . time() . '_' . uniqid() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                if ($image_path && file_exists('../' . $image_path)) {
                    unlink('../' . $image_path);
                }
                $image_path = 'assets/img/products/' . $new_filename;
            }
        }
    }
    
    try {
        $stmt = $conn->prepare("
            UPDATE products 
            SET name = ?, description = ?, detailed_description = ?, features = ?, usage_instructions = ?, specifications = ?, price = ?, stock = ?, brand_id = ?, category_id = ?, image = ? 
            WHERE id = ?
        ");
        $stmt->bind_param("ssssssdiissi", $name, $description, $detailed_description, $features, $usage_instructions, $specifications, $price, $stock, $brand_id, $category_id, $image_path, $id);
        $stmt->execute();
        $stmt->close();
        
        $_SESSION['success'] = 'Ürün başarıyla güncellendi!';
        header('Location: products.php');
        exit();
    } catch (Exception $e) {
        $_SESSION['error'] = 'Ürün güncellenirken hata oluştu: ' . $e->getMessage();
    }
}

// Markaları ve kategorileri çek
$brands_result = $conn->query("SELECT * FROM brands ORDER BY name");
$brands = $brands_result->fetch_all(MYSQLI_ASSOC);
$brands_result->free();

$categories_result = $conn->query("SELECT * FROM categories ORDER BY name");
$categories = $categories_result->fetch_all(MYSQLI_ASSOC);
$categories_result->free();

// Ürünleri listele
$products_result = $conn->query("
    SELECT p.*, b.name as brand_name, c.name as category_name 
    FROM products p 
    LEFT JOIN brands b ON p.brand_id = b.id 
    LEFT JOIN categories c ON p.category_id = c.id 
    ORDER BY p.created_at DESC
");
$products = $products_result->fetch_all(MYSQLI_ASSOC);
$products_result->free();

// Düzenlenecek ürün varsa bilgilerini al
$edit_product = null;
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $_GET['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $edit_product = $result->fetch_assoc();
    $stmt->close();
    
    // Edit modunda features ve specifications'ı array'e çevir
    if ($edit_product) {
        $edit_product['features_array'] = $edit_product['features'] ? explode('\\n', $edit_product['features']) : [''];
        $edit_product['specs_array'] = [];
        if ($edit_product['specifications']) {
            $specs = explode('\\n', $edit_product['specifications']);
            foreach ($specs as $spec) {
                $parts = explode(':', $spec, 2);
                if (count($parts) === 2) {
                    $edit_product['specs_array'][] = [
                        'key' => trim($parts[0]),
                        'value' => trim($parts[1])
                    ];
                }
            }
        }
        if (empty($edit_product['specs_array'])) {
            $edit_product['specs_array'] = [['key' => '', 'value' => '']];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ürün Yönetimi - Admin Paneli</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        body { 
            background-color: #f8f9fa; 
            font-family: 'Inter', sans-serif; 
        }
        
        .sidebar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            z-index: 1000;
            padding-top: 20px;
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            border-left: 3px solid transparent;
            transition: all 0.3s ease;
            margin-bottom: 5px;
        }
        
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background-color: rgba(255,255,255,0.1);
            border-left-color: white;
        }
        
        .main-content { 
            margin-left: 250px; 
            padding: 30px; 
        }
        
        .top-navbar {
            background: white;
            padding: 15px 30px;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-left: 250px;
            position: sticky;
            top: 0;
            z-index: 999;
        }
        
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-left: 4px solid #667eea;
            transition: all 0.3s ease;
            margin-bottom: 30px;
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .card-header {
            background: white;
            border-bottom: 1px solid #e9ecef;
            padding: 20px;
            border-radius: 15px 15px 0 0;
        }
        
        .table-hover tbody tr:hover {
            background-color: #f8f9fa;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #5a6fd6 0%, #6c4596 100%);
        }
        
        .star-rating {
            color: #ffc107;
        }
        
        .star-rating.small {
            font-size: 0.8rem;
        }
        
        .form-textarea {
            min-height: 100px;
        }
        
        .feature-item, .spec-row {
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #e9ecef;
            border-radius: 5px;
            background: #f8f9fa;
        }
        
        .add-feature-btn, .add-spec-btn {
            margin-top: 10px;
        }
        
        .remove-btn {
            margin-left: 10px;
        }
        
        .spec-table {
            width: 100%;
        }
        
        .spec-table input {
            width: 100%;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="text-center mb-4 px-3">
            <h5 class="text-white fw-bold mb-1">Kafkas Boya</h5>
            <small class="text-white-50">Admin Paneli</small>
        </div>
        
        <nav class="nav flex-column">
            <a href="dashboard.php" class="nav-link"><i class="fas fa-chart-line me-2" style="width:20px"></i> Dashboard</a>
            <a href="products.php" class="nav-link active"><i class="fas fa-boxes me-2" style="width:20px"></i> Ürünler</a>
            <a href="categories.php" class="nav-link"><i class="fas fa-list me-2" style="width:20px"></i> Kategoriler</a>
            <a href="brands.php" class="nav-link"><i class="fas fa-tag me-2" style="width:20px"></i> Markalar</a>
            <a href="orders.php" class="nav-link"><i class="fas fa-receipt me-2" style="width:20px"></i> Siparişler</a>
            <a href="users.php" class="nav-link"><i class="fas fa-users me-2" style="width:20px"></i> Kullanıcılar</a>
            <a href="user-contacts.php" class="nav-link"><i class="fas fa-envelope me-2" style="width:20px"></i> İletişim Mesajları</a>
            <a href="last-comments.php" class="nav-link"><i class="fas fa-comments me-2" style="width:20px"></i> Son Yorumlar</a>
            <hr class="bg-white-50 mx-3">
            <a href="/logout.php" class="nav-link"><i class="fas fa-sign-out-alt me-2" style="width:20px"></i> Çıkış Yap</a>
        </nav>
    </div>

    <!-- Top Navbar -->
    <div class="top-navbar">
        <h4 class="mb-0 fw-bold">Ürün Yönetimi</h4>
        <div class="d-flex align-items-center gap-3">
            <span class="text-muted"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                <i class="fas fa-user"></i>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
            <h1 class="h2">Ürün Yönetimi</h1>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal">
                <i class="fas fa-plus me-2"></i>Yeni Ürün Ekle
            </button>
        </div>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Tüm Ürünler</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Resim</th>
                                <th>Ürün Adı</th>
                                <th>Marka</th>
                                <th>Kategori</th>
                                <th>Fiyat</th>
                                <th>Stok</th>
                                <th>Durum</th>
                                <th>Puan</th>
                                <th>Yorum</th>
                                <th>İşlemler</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td><?php echo $product['id']; ?></td>
                                    <td>
                                        <?php if ($product['image']): ?>
                                            <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                                                 alt="" style="width: 50px; height: 50px; object-fit: cover;" class="rounded">
                                        <?php else: ?>
                                            <span class="text-muted">Resim yok</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                                    <td><?php echo htmlspecialchars($product['brand_name']); ?></td>
                                    <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                                    <td>₺<?php echo number_format($product['price'], 2); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $product['stock'] > 10 ? 'success' : ($product['stock'] > 0 ? 'warning' : 'danger'); ?>">
                                            <?php echo $product['stock']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $product['stock'] > 0 ? 'success' : 'secondary'; ?>">
                                            <?php echo $product['stock'] > 0 ? 'Aktif' : 'Pasif'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php 
                                        $rating_stmt = $conn->prepare("SELECT AVG(rating) as avg_rating FROM reviews WHERE product_id = ?");
                                        $rating_stmt->bind_param("i", $product['id']);
                                        $rating_stmt->execute();
                                        $rating_result = $rating_stmt->get_result();
                                        $rating_data = $rating_result->fetch_assoc();
                                        $avg_rating = $rating_data['avg_rating'] ? round($rating_data['avg_rating'], 1) : 0;
                                        $rating_stmt->close();
                                        ?>
                                        <div class="star-rating small">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <i class="fas fa-star <?php echo $i <= round($avg_rating) ? 'text-warning' : 'text-muted'; ?>" style="font-size: 0.8rem;"></i>
                                            <?php endfor; ?>
                                            <br>
                                            <small class="text-muted">(<?php echo $avg_rating; ?>)</small>
                                        </div>
                                    </td>
                                    <td>
                                        <?php 
                                        $count_stmt = $conn->prepare("SELECT COUNT(*) as review_count FROM reviews WHERE product_id = ?");
                                        $count_stmt->bind_param("i", $product['id']);
                                        $count_stmt->execute();
                                        $count_result = $count_stmt->get_result();
                                        $count_data = $count_result->fetch_assoc();
                                        $count_stmt->close();
                                        ?>
                                        <span class="badge bg-info"><?php echo $count_data['review_count']; ?></span>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="?action=edit&id=<?php echo $product['id']; ?>" class="btn btn-sm btn-warning">
                                                <i class="fas fa-edit me-1"></i>Düzenle
                                            </a>
                                            <a href="?action=delete&id=<?php echo $product['id']; ?>" 
                                               class="btn btn-sm btn-danger" 
                                               onclick="return confirm('Bu ürünü silmek istediğinizden emin misiniz?')">
                                                <i class="fas fa-trash me-1"></i>Sil
                                            </a>
                                            <a href="?action=toggle_status&id=<?php echo $product['id']; ?>" 
                                               class="btn btn-sm <?php echo $product['stock'] > 0 ? 'btn-success' : 'btn-secondary'; ?>"
                                               onclick="return confirm('Ürün durumunu değiştirmek istediğinizden emin misiniz?')">
                                                <i class="fas <?php echo $product['stock'] > 0 ? 'fa-eye' : 'fa-eye-slash'; ?> me-1"></i>
                                                <?php echo $product['stock'] > 0 ? 'Aktif' : 'Pasif'; ?>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Ürün Ekleme Modal -->
        <div class="modal fade" id="addProductModal" tabindex="-1">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <form method="POST" action="?action=add" enctype="multipart/form-data" id="addProductForm">
                        <div class="modal-header">
                            <h5 class="modal-title">Yeni Ürün Ekle</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Ürün Adı *</label>
                                        <input type="text" name="name" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Fiyat (₺) *</label>
                                        <input type="number" name="price" class="form-control" step="0.01" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Kısa Açıklama *</label>
                                <textarea name="description" class="form-control form-textarea" rows="3" placeholder="Ürünün kısa tanımı..." required></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Detaylı Ürün Açıklaması</label>
                                <textarea name="detailed_description" class="form-control form-textarea" rows="4" placeholder="Ürünün detaylı açıklaması..."></textarea>
                            </div>
                            
                            <!-- Özellikler Bölümü -->
                            <div class="mb-3">
                                <label class="form-label fw-bold">Öne Çıkan Özellikler</label>
                                <div id="features-container">
                                    <div class="feature-item">
                                        <div class="input-group">
                                            <input type="text" name="features[]" class="form-control" placeholder="Özellik girin (örn: Su bazlı formül)">
                                            <button type="button" class="btn btn-outline-danger remove-feature" title="Sil">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-outline-primary btn-sm add-feature-btn">
                                    <i class="fas fa-plus me-1"></i>Yeni Özellik Ekle
                                </button>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Kullanım Talimatları</label>
                                <textarea name="usage_instructions" class="form-control form-textarea" rows="4" placeholder="Her adımı yeni satıra yazın..."></textarea>
                            </div>
                            
                            <!-- Teknik Özellikler Bölümü -->
                            <div class="mb-3">
                                <label class="form-label fw-bold">Teknik Özellikler</label>
                                <div class="table-responsive">
                                    <table class="table table-bordered spec-table">
                                        <thead>
                                            <tr>
                                                <th width="40%">Özellik</th>
                                                <th width="40%">Değer</th>
                                                <th width="20%">İşlem</th>
                                            </tr>
                                        </thead>
                                        <tbody id="specs-container">
                                            <tr class="spec-row">
                                                <td>
                                                    <input type="text" name="spec_keys[]" class="form-control" placeholder="Özellik adı (örn: Renk)">
                                                </td>
                                                <td>
                                                    <input type="text" name="spec_values[]" class="form-control" placeholder="Değer (örn: Beyaz)">
                                                </td>
                                                <td>
                                                    <button type="button" class="btn btn-outline-danger btn-sm remove-spec" title="Sil">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <button type="button" class="btn btn-outline-primary btn-sm add-spec-btn">
                                    <i class="fas fa-plus me-1"></i>Yeni Özellik Ekle
                                </button>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Stok *</label>
                                    <input type="number" name="stock" class="form-control" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Marka *</label>
                                    <select name="brand_id" class="form-select" required>
                                        <option value="">Seçiniz</option>
                                        <?php foreach ($brands as $brand): ?>
                                            <option value="<?php echo $brand['id']; ?>"><?php echo htmlspecialchars($brand['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Kategori *</label>
                                    <select name="category_id" class="form-select" required>
                                        <option value="">Seçiniz</option>
                                        <?php foreach ($categories as $category): ?>
                                            <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Ürün Resmi</label>
                                <input type="file" name="image" class="form-control" accept="image/*">
                                <small class="text-muted">JPG, PNG, WEBP veya GIF formatında resim yükleyebilirsiniz.</small>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                            <button type="submit" class="btn btn-primary">Kaydet</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Ürün Düzenleme Formu -->
        <?php if ($edit_product): ?>
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="mb-0">Ürün Düzenle</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="?action=edit" enctype="multipart/form-data" id="editProductForm">
                    <input type="hidden" name="id" value="<?php echo $edit_product['id']; ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Ürün Adı *</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($edit_product['name']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Fiyat (₺) *</label>
                            <input type="number" name="price" class="form-control" step="0.01" value="<?php echo $edit_product['price']; ?>" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Kısa Açıklama *</label>
                        <textarea name="description" class="form-control form-textarea" rows="3" required><?php echo htmlspecialchars($edit_product['description']); ?></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Detaylı Ürün Açıklaması</label>
                        <textarea name="detailed_description" class="form-control form-textarea" rows="4"><?php echo htmlspecialchars($edit_product['detailed_description'] ?? ''); ?></textarea>
                    </div>
                    
                    <!-- Özellikler Bölümü - Edit -->
                    <div class="mb-3">
                        <label class="form-label fw-bold">Öne Çıkan Özellikler</label>
                        <div id="edit-features-container">
                            <?php foreach ($edit_product['features_array'] as $index => $feature): ?>
                                <div class="feature-item">
                                    <div class="input-group">
                                        <input type="text" name="features[]" class="form-control" value="<?php echo htmlspecialchars($feature); ?>" placeholder="Özellik girin">
                                        <button type="button" class="btn btn-outline-danger remove-feature" title="Sil">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" class="btn btn-outline-primary btn-sm add-feature-btn">
                            <i class="fas fa-plus me-1"></i>Yeni Özellik Ekle
                        </button>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Kullanım Talimatları</label>
                        <textarea name="usage_instructions" class="form-control form-textarea" rows="4"><?php echo htmlspecialchars($edit_product['usage_instructions'] ?? ''); ?></textarea>
                    </div>
                    
                    <!-- Teknik Özellikler Bölümü - Edit -->
                    <div class="mb-3">
                        <label class="form-label fw-bold">Teknik Özellikler</label>
                        <div class="table-responsive">
                            <table class="table table-bordered spec-table">
                                <thead>
                                    <tr>
                                        <th width="40%">Özellik</th>
                                        <th width="40%">Değer</th>
                                        <th width="20%">İşlem</th>
                                    </tr>
                                </thead>
                                <tbody id="edit-specs-container">
                                    <?php foreach ($edit_product['specs_array'] as $index => $spec): ?>
                                        <tr class="spec-row">
                                            <td>
                                                <input type="text" name="spec_keys[]" class="form-control" value="<?php echo htmlspecialchars($spec['key']); ?>" placeholder="Özellik adı">
                                            </td>
                                            <td>
                                                <input type="text" name="spec_values[]" class="form-control" value="<?php echo htmlspecialchars($spec['value']); ?>" placeholder="Değer">
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-outline-danger btn-sm remove-spec" title="Sil">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <button type="button" class="btn btn-outline-primary btn-sm add-spec-btn">
                            <i class="fas fa-plus me-1"></i>Yeni Özellik Ekle
                        </button>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Stok *</label>
                            <input type="number" name="stock" class="form-control" value="<?php echo $edit_product['stock']; ?>" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Marka *</label>
                            <select name="brand_id" class="form-select" required>
                                <?php foreach ($brands as $brand): ?>
                                    <option value="<?php echo $brand['id']; ?>" <?php echo $brand['id'] == $edit_product['brand_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($brand['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Kategori *</label>
                            <select name="category_id" class="form-select" required>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" <?php echo $category['id'] == $edit_product['category_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($category['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Ürün Resmi</label>
                        <?php if ($edit_product['image']): ?>
                            <div class="mb-2">
                                <img src="../<?php echo htmlspecialchars($edit_product['image']); ?>" alt="" style="max-width: 200px;" class="rounded">
                                <p class="text-muted">Mevcut resim</p>
                            </div>
                        <?php endif; ?>
                        <input type="file" name="image" class="form-control" accept="image/*">
                        <small class="text-muted">Yeni resim yüklemek için seçin. Boş bırakılırsa mevcut resim korunur.</small>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Güncelle</button>
                    <a href="products.php" class="btn btn-secondary">İptal</a>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Özellik ekleme fonksiyonu
    document.addEventListener('DOMContentLoaded', function() {
        // Özellik ekleme
        function addFeature(containerId) {
            const container = document.getElementById(containerId);
            const newFeature = document.createElement('div');
            newFeature.className = 'feature-item';
            newFeature.innerHTML = `
                <div class="input-group">
                    <input type="text" name="features[]" class="form-control" placeholder="Özellik girin">
                    <button type="button" class="btn btn-outline-danger remove-feature" title="Sil">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
            container.appendChild(newFeature);
            
            // Silme butonuna event listener ekle
            newFeature.querySelector('.remove-feature').addEventListener('click', function() {
                newFeature.remove();
            });
        }
        
        // Teknik özellik ekleme
        function addSpec(containerId) {
            const container = document.getElementById(containerId);
            const newRow = document.createElement('tr');
            newRow.className = 'spec-row';
            newRow.innerHTML = `
                <td>
                    <input type="text" name="spec_keys[]" class="form-control" placeholder="Özellik adı">
                </td>
                <td>
                    <input type="text" name="spec_values[]" class="form-control" placeholder="Değer">
                </td>
                <td>
                    <button type="button" class="btn btn-outline-danger btn-sm remove-spec" title="Sil">
                        <i class="fas fa-times"></i>
                    </button>
                </td>
            `;
            container.appendChild(newRow);
            
            // Silme butonuna event listener ekle
            newRow.querySelector('.remove-spec').addEventListener('click', function() {
                newRow.remove();
            });
        }
        
        // Ekleme butonlarına event listener ekle
        document.querySelectorAll('.add-feature-btn').forEach(button => {
            button.addEventListener('click', function() {
                const containerId = this.previousElementSibling.id;
                addFeature(containerId);
            });
        });
        
        document.querySelectorAll('.add-spec-btn').forEach(button => {
            button.addEventListener('click', function() {
                const containerId = this.previousElementSibling.querySelector('tbody').id;
                addSpec(containerId);
            });
        });
        
        // Mevcut silme butonlarına event listener ekle
        document.querySelectorAll('.remove-feature').forEach(button => {
            button.addEventListener('click', function() {
                this.closest('.feature-item').remove();
            });
        });
        
        document.querySelectorAll('.remove-spec').forEach(button => {
            button.addEventListener('click', function() {
                this.closest('.spec-row').remove();
            });
        });
        
        // Modal açıldığında temizle
        const addModal = document.getElementById('addProductModal');
        if (addModal) {
            addModal.addEventListener('show.bs.modal', function() {
                // Sadece bir özellik ve bir spec kalacak şekilde temizle
                const featuresContainer = document.getElementById('features-container');
                const specsContainer = document.getElementById('specs-container');
                
                if (featuresContainer.children.length > 1) {
                    featuresContainer.innerHTML = featuresContainer.children[0].outerHTML;
                }
                
                if (specsContainer.children.length > 1) {
                    specsContainer.innerHTML = specsContainer.children[0].outerHTML;
                }
                
                // Inputları temizle
                featuresContainer.querySelector('input').value = '';
                specsContainer.querySelectorAll('input').forEach(input => input.value = '');
            });
        }
    });
    </script>
</body>
</html>