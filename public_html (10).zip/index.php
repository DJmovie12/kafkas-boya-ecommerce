<?php
$page_title = "Kafkas Boya - Profesyonel Boya Çözümleri";
require_once 'includes/header.php';
require_once 'includes/db_connect.php';
?>
<style>
/* Product Cards */
.product-card {
    transition: all 0.3s ease;
}

.product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15) !important;
}

.product-image {
    position: relative;
    overflow: hidden;
}

.product-actions {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(255, 255, 255, 0.95);
    transform: translateY(100%);
    transition: transform 0.3s ease;
    z-index: 10;
}

.product-card:hover .product-actions {
    transform: translateY(0);
}

.star-rating {
    color: #ffc107;
}

/* Mobile Responsive for Products */
@media (max-width: 767px) {
    .mobile-product-grid {
        display: grid !important;
        grid-template-columns: 1fr 1fr !important;
        gap: 12px !important;
        width: 100% !important;
    }
    
    .mobile-product-grid > div {
        width: 100% !important;
        display: flex !important;
        justify-content: center !important;
    }
    
    .mobile-product-card {
        width: 100% !important;
        max-width: 165px !important;
        margin: 0 auto !important;
    }
    
    .mobile-product-image {
        height: 140px !important;
    }
    
    .mobile-product-info {
        padding: 12px !important;
    }
    
    .mobile-product-info h6 {
        font-size: 13px !important;
        line-height: 1.3 !important;
        margin-bottom: 8px !important;
    }
    
    .mobile-product-info p {
        font-size: 11px !important;
        line-height: 1.2 !important;
        margin-bottom: 8px !important;
    }
    
    .mobile-product-price {
        font-size: 14px !important;
    }
    
    .mobile-centered {
        text-align: center !important;
        display: flex !important;
        justify-content: center !important;
        align-items: center !important;
    }
    
    .mobile-full-center {
        display: flex !important;
        justify-content: center !important;
        align-items: center !important;
        flex-direction: column !important;
    }
}

/* Mobile Responsive for Brands */
@media (max-width: 767px) {
    .mobile-brand-grid {
        display: grid !important;
        grid-template-columns: 1fr 1fr !important;
        gap: 12px !important;
        width: 100% !important;
    }
    
    .mobile-brand-grid > div {
        width: 100% !important;
        display: flex !important;
        justify-content: center !important;
    }
    
    .mobile-brand-card {
        width: 100% !important;
        max-width: 140px !important;
        margin: 0 auto !important;
        padding: 16px !important;
    }
    
    .mobile-brand-logo {
        width: 50px !important;
        height: 50px !important;
    }
    
    .mobile-brand-logo img {
        width: 45px !important;
        height: 45px !important;
    }
    
    .mobile-brand-card h5 {
        font-size: 13px !important;
        margin-bottom: 6px !important;
    }
    
    .mobile-brand-card p {
        font-size: 10px !important;
        margin-bottom: 8px !important;
    }
    
    .mobile-brand-card .btn {
        font-size: 10px !important;
        padding: 4px 8px !important;
    }
}

/* General Mobile Styles */
@media (max-width: 767px) {
    .mobile-text-center {
        text-align: center !important;
    }
    
    .mobile-justify-center {
        justify-content: center !important;
    }
    
    .mobile-mx-auto {
        margin-left: auto !important;
        margin-right: auto !important;
    }
    
    .mobile-w-100 {
        width: 100% !important;
    }
}
</style>

    <!-- HERO SECTION -->
    <section class="hero-section position-relative overflow-hidden" style="margin-top: 70px; height: 100vh;">
        <div class="hero-background" style="background-image: url('assets/img/slide-1.webp');"></div>
        <div class="hero-gradient-overlay"></div>

        <div class="container h-100 position-relative z-index-1">
            <div class="row h-100 align-items-center">
                <div class="col-lg-6 d-flex flex-column justify-content-center mobile-text-center" data-aos="fade-right">
                    <h1 class="display-3 fw-bold text-white mb-4" style="font-family: 'Playfair Display', serif;">
                        Evinize <span class="text-warning">Renk</span> Katın
                    </h1>
                    <p class="lead text-light mb-4">
                        Kafkas Boya olarak 20 yıllık deneyimimizle, profesyonel boya çözümleri sunuyoruz.
                        En kaliteli markalar, geniş ürün yelpazesi ve uzman desteğiyle yanınızdayız.
                    </p>
                    <div class="d-flex flex-wrap gap-3 mobile-justify-center">
                        <a href="shop.php" class="btn btn-warning btn-lg px-4 py-3 rounded-pill fw-bold">
                            <i class="fas fa-shopping-cart me-2"></i>Alışverişe Başla
                        </a>
                        <a href="#favori-markalar" class="btn btn-outline-light btn-lg px-4 py-3 rounded-pill fw-bold">
                            <i class="fas fa-star me-2"></i>Markalarımız
                        </a>
                    </div>
                </div>
                <div class="col-lg-6" data-aos="fade-left"></div>
            </div>
        </div>
    </section>

    <!-- MARKALAR SECTION -->
    <section id="favori-markalar" class="py-5 bg-white">
        <div class="container">
            <div class="text-center mb-5" data-aos="fade-up">
                <h2 class="display-5 fw-bold text-dark mb-3" style="font-family: 'Playfair Display', serif;">
                    Anlaştığımız <span class="text-primary">Boya Markaları</span>
                </h2>
                <p class="lead text-muted">Sektörün lider markalarıyla iş ortaklığımız</p>
            </div>

            <div class="row g-4 justify-content-center mobile-brand-grid">
                <?php
                $brands = ['polisan', 'filli-boya', 'marshall', 'dyo', 'permolit'];
                $brand_names = ['Polisan', 'Filli Boya', 'Marshall', 'DYO', 'Permolit'];
                $brand_colors = ['primary', 'success', 'warning', 'danger', 'info'];
                $brand_descriptions = ['Premium kalite', 'Geniş renk paleti', 'Dayanıklı çözümler', 'Ekonomik çözümler', 'Profesyonel seçim'];

                foreach ($brands as $index => $brand) {
                    $brand_name = $brand_names[$index];
                    $brand_color = $brand_colors[$index];
                    $brand_desc = $brand_descriptions[$index];
                ?>
                <div class="col-lg-2 col-md-4 col-6 text-center" data-aos="zoom-in" data-aos-delay="<?php echo ($index * 100) + 100; ?>">
                    <div class="brand-card h-100 p-4 bg-white rounded-4 shadow-sm text-center hover-lift mobile-brand-card">
                        <div class="brand-logo mb-3 mobile-full-center">
                            <div class="brand-icon bg-<?php echo $brand_color; ?> bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mobile-brand-logo">
                                <img src="assets/img/<?php echo $brand; ?>.webp" alt="<?php echo $brand_name; ?> logo" style="width: 100%; height: auto; border-radius: 100%;">
                            </div>
                        </div>
                        <h5 class="fw-semibold text-dark mb-2"><?php echo $brand_name; ?></h5>
                        <p class="text-muted small mb-3"><?php echo $brand_desc; ?></p>
                        <a href="shop.php?marka=<?php echo $brand; ?>" class="btn btn-outline-primary btn-sm">İncele</a>
                    </div>
                </div>
                <?php } ?>

                <div class="col-lg-2 col-md-4 col-6 text-center" data-aos="zoom-in" data-aos-delay="<?php echo (count($brands) * 100) + 100; ?>">
                    <div class="brand-card h-100 p-4 bg-primary bg-opacity-75 rounded-4 shadow-lg text-center hover-lift mobile-brand-card">
                        <div class="brand-logo mb-3 mobile-full-center">

                        </div>
                        <h5 class="fw-semibold text-white mb-2">Tüm Markalarımız</h5>
                        <p class="text-white small mb-3">Çok daha fazlasını keşfet</p>
                        <a href="shop.php" class="btn btn-light btn-sm">Mağazaya Git</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAVORI ÜRÜNLER SECTION -->
    <section class="py-5 bg-white">
        <div class="container">
            <div class="text-center mb-5" data-aos="fade-up">
                <h2 class="display-5 fw-bold text-dark mb-3" style="font-family: 'Playfair Display', serif;">
                    <span class="text-primary">En Beğenilen</span> Ürünler
                </h2>
                <p class="lead text-muted">Müşterilerimizin en çok yorum yaptığı ve en yüksek puan verdiği ürünler</p>
            </div>

            <div class="row g-4 mobile-product-grid">
                <?php
                // En çok yorum ve en yüksek puan alan ürünleri çek
                $popular_sql = "SELECT 
                    p.*, 
                    b.name as brand_name,
                    COUNT(r.id) as review_count,
                    AVG(r.rating) as avg_rating,
                    (COUNT(r.id) * 0.6 + AVG(r.rating) * 0.4) as popularity_score
                FROM products p 
                LEFT JOIN brands b ON p.brand_id = b.id 
                LEFT JOIN reviews r ON p.id = r.product_id 
                WHERE p.stock > 0
                GROUP BY p.id 
                HAVING review_count > 0
                ORDER BY popularity_score DESC, review_count DESC, avg_rating DESC 
                LIMIT 4";
                
                $popular_result = $conn->query($popular_sql);
                
                if ($popular_result && $popular_result->num_rows > 0) {
                    $popular_products = $popular_result->fetch_all(MYSQLI_ASSOC);
                    
                    foreach ($popular_products as $index => $product) {
                        // Badge türlerini belirle
                        $badge_types = ['Popüler', 'En Çok Yorum', 'Yüksek Puan', 'Favori'];
                        $badge = $badge_types[$index % 4];
                        
                        // Rating ve review bilgilerini hazırla
                        $avg_rating = $product['avg_rating'] ? round($product['avg_rating'], 1) : 0;
                        $review_count = $product['review_count'] ?: 0;
                        
                        // Yıldız rating gösterimi
                        $stars = '';
                        $full_stars = floor($avg_rating);
                        $has_half_star = ($avg_rating - $full_stars) >= 0.5;
                        
                        for ($i = 1; $i <= 5; $i++) {
                            if ($i <= $full_stars) {
                                $stars .= '<i class="fas fa-star star-rating"></i>';
                            } elseif ($i == $full_stars + 1 && $has_half_star) {
                                $stars .= '<i class="fas fa-star-half-alt star-rating"></i>';
                            } else {
                                $stars .= '<i class="far fa-star star-rating"></i>';
                            }
                        }
                    ?>
                    <div class="col-lg-3 col-md-6 text-center" data-aos="fade-up" data-aos-delay="<?php echo ($index * 100); ?>">
                        <div class="product-card rounded-4 overflow-hidden shadow-sm hover-shadow h-100 d-flex flex-column mobile-product-card">
                            <div class="product-image position-relative overflow-hidden mobile-product-image" style="background-color: #f8f9fa;">
                                <?php if (!empty($product['image'])): ?>
                                    <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                                         alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                         class="w-100 h-100" style="object-fit: cover;">
                                <?php else: ?>
                                    <div class="w-100 h-100 d-flex align-items-center justify-content-center">
                                        <i class="fas fa-image text-muted" style="font-size: 1.5rem;"></i>
                                    </div>
                                <?php endif; ?>
                                
                                <!-- Badge -->
                                <span class="badge bg-primary position-absolute top-0 start-0 m-2" style="font-size: 10px;"><?php echo $badge; ?></span>
                                
                                <!-- Review Badge -->
                                <?php if ($review_count > 0): ?>
                                    <span class="badge bg-success position-absolute top-0 end-0 m-2" style="font-size: 10px;">
                                        <i class="fas fa-comment me-1"></i><?php echo $review_count; ?>
                                    </span>
                                <?php endif; ?>
                                
                                <div class="product-actions d-flex flex-column gap-2 p-2">
                                    <a href="shop-single.php?id=<?php echo $product['id']; ?>" class="btn btn-primary btn-sm w-100" style="font-size: 11px; padding: 4px 8px;">
                                        <i class="fas fa-eye me-1"></i>Detaylı İncele
                                    </a>
                                    <button class="btn btn-warning btn-sm w-100 add-to-cart" data-product="<?php echo $product['id']; ?>" style="font-size: 11px; padding: 4px 8px;">
                                        <i class="fas fa-shopping-cart me-1"></i>Sepete Ekle
                                    </button>
                                </div>
                            </div>
                            
                            <div class="product-info mobile-product-info flex-grow-1 d-flex flex-column mobile-text-center">
                                <h6 class="fw-semibold text-dark mb-2"><?php echo htmlspecialchars($product['name']); ?></h6>
                                
                                <!-- Rating Section -->
                                <div class="mb-2 mobile-full-center">
                                    <div class="d-flex align-items-center mb-1 mobile-justify-center">
                                        <div style="font-size: 12px;">
                                            <?php echo $stars; ?>
                                        </div>
                                        <small class="text-muted ms-1" style="font-size: 11px;"><?php echo $avg_rating; ?>/5</small>
                                    </div>
                                    <?php if ($review_count > 0): ?>
                                        <small class="text-muted" style="font-size: 10px;">
                                            <i class="fas fa-comment me-1"></i><?php echo $review_count; ?> yorum
                                        </small>
                                    <?php else: ?>
                                        <small class="text-muted" style="font-size: 10px;">Henüz yorum yok</small>
                                    <?php endif; ?>
                                </div>
                                
                                <p class="text-muted small mb-3" style="font-size: 11px; line-height: 1.3;">
                                    <?php 
                                    if (!empty($product['brand_name'])) {
                                        echo htmlspecialchars($product['brand_name']) . ' marka';
                                    } else {
                                        echo 'Profesyonel boya';
                                    }
                                    ?>
                                </p>
                                
                                <h5 class="text-primary fw-bold mt-auto mobile-product-price">₺<?php echo number_format($product['price'], 2, ',', '.'); ?></h5>
                            </div>
                        </div>
                    </div>
                    <?php 
                    }
                } else {
                    // Popüler ürün yoksa normal ürünleri göster
                    $fallback_sql = "SELECT p.*, b.name as brand_name FROM products p 
                                    LEFT JOIN brands b ON p.brand_id = b.id 
                                    WHERE p.stock > 0
                                    ORDER BY p.created_at DESC LIMIT 4";
                    
                    $fallback_result = $conn->query($fallback_sql);
                    
                    if ($fallback_result && $fallback_result->num_rows > 0) {
                        $fallback_products = $fallback_result->fetch_all(MYSQLI_ASSOC);
                        
                        foreach ($fallback_products as $index => $product) {
                            $badge_types = ['Yeni', 'Popüler', 'Önerilen', 'Favori'];
                            $badge = $badge_types[$index % 4];
                        ?>
                        <div class="col-lg-3 col-md-6 text-center" data-aos="fade-up" data-aos-delay="<?php echo ($index * 100); ?>">
                            <div class="product-card rounded-4 overflow-hidden shadow-sm hover-shadow h-100 d-flex flex-column mobile-product-card">
                                <div class="product-image position-relative overflow-hidden mobile-product-image" style="background-color: #f8f9fa;">
                                    <?php if (!empty($product['image'])): ?>
                                        <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                                             alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                             class="w-100 h-100" style="object-fit: cover;">
                                    <?php else: ?>
                                        <div class="w-100 h-100 d-flex align-items-center justify-content-center">
                                            <i class="fas fa-image text-muted" style="font-size: 1.5rem;"></i>
                                        </div>
                                    <?php endif; ?>
                                    <span class="badge bg-primary position-absolute top-0 start-0 m-2" style="font-size: 10px;"><?php echo $badge; ?></span>
                                    <div class="product-actions d-flex flex-column gap-2 p-2">
                                        <a href="shop-single.php?id=<?php echo $product['id']; ?>" class="btn btn-primary btn-sm w-100" style="font-size: 11px; padding: 4px 8px;">
                                            <i class="fas fa-eye me-1"></i>Detaylı İncele
                                        </a>
                                        <button class="btn btn-warning btn-sm w-100 add-to-cart" data-product="<?php echo $product['id']; ?>" style="font-size: 11px; padding: 4px 8px;">
                                            <i class="fas fa-shopping-cart me-1"></i>Sepete Ekle
                                        </button>
                                    </div>
                                </div>
                                <div class="product-info mobile-product-info flex-grow-1 d-flex flex-column mobile-text-center">
                                    <h6 class="fw-semibold text-dark mb-2"><?php echo htmlspecialchars($product['name']); ?></h6>
                                    <div class="mb-2 mobile-full-center">
                                        <i class="fas fa-star text-warning" style="font-size: 12px;"></i>
                                        <small class="text-muted" style="font-size: 11px;">Henüz değerlendirilmemiş</small>
                                    </div>
                                    <p class="text-muted small mb-3" style="font-size: 11px; line-height: 1.3;">
                                        <?php 
                                        if (!empty($product['brand_name'])) {
                                            echo htmlspecialchars($product['brand_name']) . ' marka';
                                        } else {
                                            echo 'Profesyonel boya';
                                        }
                                        ?>
                                    </p>
                                    <h5 class="text-primary fw-bold mt-auto mobile-product-price">₺<?php echo number_format($product['price'], 2, ',', '.'); ?></h5>
                                </div>
                            </div>
                        </div>
                        <?php 
                        }
                    } else {
                        echo '<div class="col-12 text-center py-5"><p class="text-muted">Ürün bulunamadı</p></div>';
                    }
                }
                ?>
            </div>

            <div class="text-center mt-5">
                <a href="shop.php" class="btn btn-primary btn-lg px-5 rounded-pill">
                    <i class="fas fa-eye me-2"></i>Tüm Ürünleri Gör
                </a>
            </div>
        </div>
    </section>

    <!-- HAKKIMIZDA SECTION -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row align-items-center g-4">
                <div class="col-lg-6" data-aos="fade-right">
                    <div class="about-visual rounded-4 overflow-hidden h-100 shadow-lg" style="background-image: url('assets/img/banner_img_01.webp'); background-size: cover; background-position: center; min-height: 400px; position: relative;">
                        <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0, 0, 0, 0.4);"></div>
                        <div class="d-flex flex-column justify-content-center align-items-center h-100 p-4 text-white position-relative z-1">
                        </div>
                    </div>
                </div>

                <div class="col-lg-6" data-aos="fade-left">
                    <div class="about-content">
                        <h2 class="display-5 fw-bold text-dark mb-4" style="font-family: 'Playfair Display', serif;">
                            <span class="text-primary">Kafkas Boya</span> Hakkında
                        </h2>
                        
                        <p class="lead text-muted mb-4">
                            1995'ten bu yana Kafkas Boya, Türkiye'nin en güvenilir boya tedarikçilerinden biri olarak hizmet vermektedir.
                        </p>

                        <div class="mb-4">
                            <h5 class="text-dark fw-bold mb-3">
                                <i class="fas fa-check-circle text-success me-2"></i>Neden Biz?
                            </h5>
                            <ul class="list-unstyled">
                                <li class="mb-3">
                                    <i class="fas fa-star text-warning me-2"></i>
                                    <strong>20+ Yıl Deneyim:</strong> Sektörde köklü bir geçmişe sahibiz
                                </li>
                                <li class="mb-3">
                                    <i class="fas fa-star text-warning me-2"></i>
                                    <strong>Kaliteli Ürünler:</strong> Sadece sertifikalı ve test edilmiş ürünler
                                </li>
                                <li class="mb-3">
                                    <i class="fas fa-star text-warning me-2"></i>
                                    <strong>Uzman Ekip:</strong> Müşteri memnuniyeti için her zaman hazır
                                </li>
                                <li class="mb-3">
                                    <i class="fas fa-star text-warning me-2"></i>
                                    <strong>Hızlı Teslimat:</strong> Siparişleriniz en kısa sürede ulaşır
                                </li>
                            </ul>
                        </div>

                        <div class="d-flex gap-3 flex-wrap">
                            <a href="#contact" class="btn btn-primary btn-lg rounded-pill">
                                <i class="fas fa-envelope me-2"></i>İletişime Geç
                            </a>
                            <a href="shop.php" class="btn btn-outline-primary btn-lg rounded-pill">
                                <i class="fas fa-shopping-bag me-2"></i>Mağazayı Ziyaret Et
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- NEDEN BÄ°Z SECTION -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5" data-aos="fade-up">
                <h2 class="display-5 fw-bold text-dark mb-3">
                    Neden <span class="text-primary">Kafkas Boya?</span>
                </h2>
                <p class="lead text-muted">Müşterilerimizin tercih etme nedenleri ve sunduğumuz avantajlar</p>
            </div>

            <div class="row g-4">
                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="feature-card-modern p-4 rounded-4 text-center h-100 bg-white shadow-sm">
                        <div class="feature-icon-wrapper mb-4">
                            <div class="icon-circle bg-primary bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center">
                                <i class="fas fa-award fa-2x text-light"></i>
                            </div>
                        </div>
                        <h5 class="fw-bold mb-2 text-dark">20+ Yıl Deneyim</h5>
                        <p class="text-muted small">Boya sektöründe 20 yılı aşkın tecrübemiz ve güvenilirliğimiz</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="feature-card-modern p-4 rounded-4 text-center h-100 bg-white shadow-sm">
                        <div class="feature-icon-wrapper mb-4">
                            <div class="icon-circle bg-success bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center">
                                <i class="fas fa-check-circle fa-2x text-success"></i>
                            </div>
                        </div>
                        <h5 class="fw-bold mb-2 text-dark">Kaliteli Ürünler</h5>
                        <p class="text-muted small">Sektörün en iyi ve lider markalarıyla iş ortaklığı</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="feature-card-modern p-4 rounded-4 text-center h-100 bg-white shadow-sm">
                        <div class="feature-icon-wrapper mb-4">
                            <div class="icon-circle bg-warning bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center">
                                <i class="fas fa-headset fa-2x text-warning"></i>
                            </div>
                        </div>
                        <h5 class="fw-bold mb-2 text-dark">Uzman Destek</h5>
                        <p class="text-muted small">Uzman ekibimizle her zaman sorularınıza çözüm sunmaya hazırız</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="feature-card-modern p-4 rounded-4 text-center h-100 bg-white shadow-sm">
                        <div class="feature-icon-wrapper mb-4">
                            <div class="icon-circle bg-info bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center">
                                <i class="fas fa-truck fa-2x text-info"></i>
                            </div>
                        </div>
                        <h5 class="fw-bold mb-2 text-dark">Hızlı Teslimat</h5>
                        <p class="text-muted small">Siparişleriniz hızlı ve güvenli bir şekilde adresinize teslim edilir</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- İSTATİSTİKLER SECTION -->
    <section class="py-5 bg-primary text-white">
        <div class="container">
            <div class="row text-center g-4">
                <div class="col-md-3 col-6" data-aos="fade-up">
                    <h2 class="fw-bold mb-2" style="font-size: 3.5rem; font-family: 'Georgia', serif; font-weight: 700;">20+</h2>
                    <p class="fw-semibold" style="font-size: 1.1rem;">Yıl Deneyim</p>
                </div>
                <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="100">
                    <h2 class="fw-bold mb-2" style="font-size: 3.5rem; font-family: 'Georgia', serif; font-weight: 700;">50K+</h2>
                    <p class="fw-semibold" style="font-size: 1.1rem;">Mutlu Müşteri</p>
                </div>
                <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="200">
                    <h2 class="fw-bold mb-2" style="font-size: 3.5rem; font-family: 'Georgia', serif; font-weight: 700;">5</h2>
                    <p class="fw-semibold" style="font-size: 1.1rem;">Lider Marka</p>
                </div>
                <div class="col-md-3 col-6" data-aos="fade-up" data-aos-delay="300">
                    <h2 class="fw-bold mb-2" style="font-size: 3.5rem; font-family: 'Georgia', serif; font-weight: 700;">100%</h2>
                    <p class="fw-semibold" style="font-size: 1.1rem;">Memnuniyet</p>
                </div>
            </div>
        </div>
    </section>

    <!-- KAMPANYA BANNER -->
    <section class="py-5 bg-white">
        <div class="container">
            <div class="row align-items-center g-4">
                <div class="col-lg-8" data-aos="fade-right">
                    <h3 class="display-5 fw-bold text-dark mb-3">
                        <i class="fas fa-gift text-primary me-2"></i>Özel Teklifler
                    </h3>
                    <p class="lead text-muted mb-3">
                        Bu ay yapılan sipariş miktarına göre %10 - %20 arasında indirim fırsatı!
                    </p>
                    <p class="text-muted">
                        <i class="fas fa-clock text-warning me-2"></i>Sınırlı zaman için geçerli
                    </p>
                </div>
                <div class="col-lg-4 text-lg-end" data-aos="fade-left">
                    <a href="shop.php" class="btn btn-primary btn-lg px-5 rounded-pill">
                        <i class="fas fa-bolt me-2"></i>Fırsatı Kaçırma!
                    </a>
                </div>
            </div>
        </div>
    </section>


    <!-- CTA SECTION -->
    <section class="py-5 bg-primary text-white position-relative overflow-hidden">
        <div class="container position-relative z-index-1">
            <div class="row align-items-center">
                <div class="col-lg-8" data-aos="fade-right">
                    <h2 class="display-4 fw-bold mb-3">Profesyonel Boya Çözümleri İçin Bize Ulaşın</h2>
                    <p class="lead mb-0 text-light">Uzman ekibimiz size en uygun ürünü seçmekte yardımcı olacak</p>
                </div>
                <div class="col-lg-4 text-lg-end" data-aos="fade-left">
                    <a href="contact.php" class="btn btn-warning btn-lg px-5 rounded-pill fw-bold">
                        <i class="fas fa-phone me-2"></i>Hemen İletişime Geç
                    </a>
                </div>
            </div>
        </div>
    </section>

<?php require_once 'includes/footer.php'; ?>