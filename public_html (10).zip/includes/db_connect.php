<?php
/**
 * Kafkas Boya E-Ticaret Sitesi
 * Veritabanı Bağlantı Dosyası
 */

// Hostinger Veritabanı Ayarları
define('DB_HOST', 'localhost');
define('DB_USER', 'u905565560_root');
define('DB_PASS', '@kafkas.Boya5');
define('DB_NAME', 'u905565560_kafkas_boya_db');

// MySQLi Bağlantısı Oluştur
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Bağlantı Kontrolü
if ($conn->connect_error) {
    // Bağlantı hatası durumunda
    error_log("Veritabanı bağlantı hatası: " . $conn->connect_error);
    $conn = null; 
    
    // Geliştirme ortamında hata göster (canlıda kapat)
    if ($_SERVER['HTTP_HOST'] == 'localhost' || $_SERVER['HTTP_HOST'] == '127.0.0.1') {
        die("Veritabanı bağlantı hatası: " . $conn->connect_error);
    }
} else {
    // UTF-8 Karakter Seti Ayarla
    $conn->set_charset("utf8mb4");

    // Hata Raporlamayı Etkinleştir (Geliştirme Aşamasında)
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    
    // Bağlantı başarılı mesajı (sadece geliştirme ortamında)
    if ($_SERVER['HTTP_HOST'] == 'localhost' || $_SERVER['HTTP_HOST'] == '127.0.0.1') {
        error_log("Veritabanı bağlantısı başarılı: " . DB_NAME);
    }
}